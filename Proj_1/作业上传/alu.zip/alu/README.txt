# Project Checkpoint 1
 - Author: [Your Name Here]
 - Date: [The Submission Date Here]
 - Course: ECE 550DK, Duke Kunshan University
 - Term: [Your Term Here]
 - Professor [Professor Name Here]

## Duke Community Standard, Affirmation
 I affirm that each submission complies with the Duke/DKU Community Standard and the guidelines set forth for this assignment.  
