# Project Checkpoint 1
 - Author: Rundong Wang
 - Date: 2023.9.15
 - Course: ECE 550DK, Duke Kunshan University
 - Term: No Team
 - Professor: Xin Li

## Duke Community Standard, Affirmation
 I affirm that each submission complies with the Duke/DKU Community Standard and the guidelines set forth for this assignment.  





